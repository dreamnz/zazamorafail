# Obtener el APK sin instalar nada (solo navegador)

1. Crea una cuenta gratuita en https://github.com y pulsa **New repository** (nombre: zazamora, privado está bien).
2. En el repositorio nuevo: **uploading an existing file** → arrastra TODO el contenido de la carpeta `zazamora`
   (incluida la carpeta oculta `.github`; si tu sistema no la muestra, usa el ZIP: GitHub no lo descomprime,
   así que descomprímelo antes en tu equipo) → **Commit changes**.
3. Ve a la pestaña **Actions** → **Compilar APK** → **Run workflow**. Tarda unos 5-10 minutos.
4. Al terminar (check verde), abre la ejecución y descarga **zazamora-debug-apk** (sección Artifacts). Es un ZIP con `zazamora-debug.apk`.
5. Pasa el APK al A54 (WhatsApp a ti mismo, Drive, cable…), ábrelo y permite «instalar apps desconocidas».
6. En la app: Perfil ▸ Catálogo ▸ pega tu client_id de Jamendo (gratis en devportal.jamendo.com).

Si la ejecución sale en rojo, copia el mensaje de error del paso que falló y pégamelo: lo corrijo.
