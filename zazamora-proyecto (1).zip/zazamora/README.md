# Zazamora

App musical Android (Kotlin · Jetpack Compose · Material 3 · Media3 · Room).
Paquete `com.zazamora.music` · Dispositivo de referencia: Samsung Galaxy A54 · minSdk 26 · target 34.

> **Estado de verificación:** el código fue escrito y revisado estáticamente (XML válido, llaves/paréntesis
> balanceados, imports internos resueltos), pero **no se ha compilado ni probado en un dispositivo** (el entorno
> de construcción no tenía Android SDK, Gradle ni red). Pega los errores de la primera compilación y se corrigen puntualmente.

## 1. Compilar e instalar en tu A54

1. Instala **Android Studio** (Koala 2024.1 o posterior). Incluye JDK 17 y el SDK; acepta instalar **Android SDK 34**.
2. `File ▸ Open…` y elige la carpeta `zazamora`. Android Studio descargará Gradle 8.9 y las dependencias (necesita internet).
3. Consigue tu **client_id de Jamendo** (ver sección 2).
4. En el A54: `Ajustes ▸ Acerca del teléfono ▸ Información del software` → toca 7 veces «Número de compilación»;
   luego `Opciones de desarrollador ▸ Depuración USB`. Conecta el cable y acepta la huella RSA.
5. Pulsa **Run ▸ app**. La app se instala y se abre.

APK independiente: `Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)`, o por terminal
(`gradle wrapper --gradle-version 8.9` una vez, para crear `gradlew`):

```
./gradlew :app:assembleDebug
```

Ruta del APK: `app/build/outputs/apk/debug/app-debug.apk` (renómbralo a `zazamora-debug.apk`).
Cópialo al teléfono y ábrelo (permite «instalar apps desconocidas» para tu gestor de archivos), o `adb install -r app-debug.apk`.

Pruebas unitarias: `./gradlew :app:testDebugUnitTest`.

## 2. Configurar el catálogo (Jamendo)

1. Crea una cuenta gratuita en <https://devportal.jamendo.com> y registra una aplicación → obtienes un **client_id**.
2. Dos opciones (la primera no requiere recompilar):
   - **En la app:** `Perfil ▸ Catálogo ▸ client_id de Jamendo ▸ Guardar`.
   - **En compilación:** copia `local.properties.example` a `local.properties` y rellena `JAMENDO_CLIENT_ID=`.
     `local.properties` está en `.gitignore`; no lo subas a git.

El client_id identifica tu app ante Jamendo (no es una contraseña de usuario), pero queda dentro del APK:
no lo publiques en repositorios abiertos.

## 3. APK de lanzamiento firmado (sin claves en el proyecto)

1. Crea un keystore fuera del repositorio: `keytool -genkeypair -v -keystore zazamora-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias zazamora`.
2. Copia `keystore.properties.example` a `keystore.properties`, rellénalo (está en `.gitignore`).
3. `./gradlew :app:assembleRelease` → `app/build/outputs/apk/release/app-release.apk`.
   Sin `keystore.properties` el release se genera sin firmar (no instalable).
4. Guarda el keystore y sus contraseñas en un gestor de contraseñas: si lo pierdes no podrás actualizar la app.

## 4. Arquitectura

Un módulo `:app` por capas (dependencias en un solo sentido) para poder extraer paquetes a módulos después.

| Paquete | Contenido |
|---|---|
| `config` | `AppContainer` (inyección manual) |
| `model` | Entidades/modelos (`Track`, `Album`, `Artist`, …) y `UiState` |
| `integration` | Contrato `MusicProvider`, `JamendoProvider`, cliente HTTP |
| `data.local` | Room: `AppDatabase` + `LibraryDao` (favoritos, historial, playlists, álbumes, artistas, descargas, búsquedas) |
| `data.prefs` | Preferencias (SharedPreferences → StateFlow) |
| `data` | `DownloadManager`, `ImageStore` |
| `data.repository` | `MusicRepository`: remoto + local |
| `player` | `PlaybackService` (MediaSessionService + ExoPlayer) y `PlaybackManager` (MediaController) |
| `ui.*` | Tema, componentes, navegación y pantallas |

Añadir otro proveedor: implementar `MusicProvider` y sustituirlo/combinarlo en `AppContainer`.

## 5. Funciones realmente implementadas (sin verificar en dispositivo)

- **Reproducción real** con Media3/ExoPlayer: reproducir/pausar, anterior/siguiente, barra de progreso con seek, aleatorio,
  repetición (off/cola/una), cola visible (saltar y quitar), «reproducir a continuación», «añadir a la cola», manejo de errores
  (mensaje + reintentar; salta a la siguiente si la pista falla), mini reproductor y pantalla completa.
- **Segundo plano:** `MediaSessionService` en primer plano, notificación multimedia, controles en pantalla de bloqueo,
  botones de auriculares/Bluetooth, gestión de foco de audio y pausa al desconectar auriculares, *wake lock* de red.
- **Catálogo (Jamendo):** búsqueda de canciones, álbumes y artistas; popular de la semana; lanzamientos; música en español
  (filtro `lang=es`); géneros; discografía de artista; detalle de álbum.
- **Biblioteca (Room, persiste tras reinicios):** favoritos, álbumes guardados, artistas seguidos, historial, recientes.
- **Playlists locales:** crear, renombrar, portada propia (galería), añadir, quitar, reordenar (subir/bajar), eliminar, reproducir.
- **Descargas:** solo pistas con `audiodownload_allowed`; progreso, espacio ocupado, eliminar y reproducción local sin conexión.
- **Búsqueda:** *debounce*, historial, sugerencias, resultados por categoría, estados de carga/error/vacío.
- **Perfil:** nombre, foto, géneros favoritos (cambian las recomendaciones), tema oscuro/claro/sistema, calidad de audio
  (MP3 96 kbps o ~192 kbps VBR), estadísticas (reproducciones, minutos estimados, artista más escuchado), temporizador de apagado.

## 6. Pendiente / no implementado

- Ecualizador, crossfade, letras (sincronizadas o no), mezclas y «descubrimiento semanal» propios.
- Playlists públicas de Jamendo y playlists públicas/privadas de usuario en un proveedor (las locales sí funcionan).
- Control de volumen propio (se usan los botones físicos / Bluetooth).
- Reordenar por arrastre (hoy con botones subir/bajar) y reordenar la cola.
- Restaurar la cola tras cerrar el proceso; descargas en servicio propio (se pausan si Android mata el proceso).
- EXIF en fotos de perfil/portada; accesibilidad revisada a fondo; Baseline Profile; textos en `strings.xml`; más tests.
- Notificación: usa el icono por defecto de Media3.

## 7. Limitaciones técnicas y legales

- **Jamendo es música independiente (Creative Commons)**: es el catálogo con **reproducción completa legal** que se puede
  integrar libremente en un reproductor propio. **No contiene los grandes artistas comerciales** (internacionales o
  latinoamericanos). La cantidad de música en español es limitada.
- **Spotify Web API**: ofrece metadatos y portadas del catálogo enorme, pero **no permite reproducir audio completo
  en un reproductor propio** (la reproducción exige su SDK/Premium y no es compatible con Media3); sus URLs de *preview* están
  descontinuadas para la mayoría de apps nuevas. Por eso no está integrado: mostraría canciones que no se pueden reproducir,
  justo lo que se pidió evitar. Si se añade en el futuro, será solo como fuente de metadatos, marcando las pistas como no reproducibles.
- No se evade DRM, suscripciones ni derechos de autor. No se descarga nada que el autor no permita.
- Las licencias CC de Jamendo tienen condiciones (atribución, uso no comercial en muchos casos). Revisa los términos de Jamendo y la
  licencia de cada pista antes de distribuir la app públicamente o monetizarla.
- Las URLs de audio y el formato de los endpoints de Jamendo se implementaron según su documentación pública v3.0
  y no se han comprobado contra la API real; si algún campo difiere, se ajusta en `JamendoProvider.kt`.
