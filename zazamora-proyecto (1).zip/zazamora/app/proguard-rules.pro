# Room y Media3 incluyen sus propias reglas de consumidor.
-keep class com.zazamora.music.model.** { *; }
