package com.zazamora.music

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zazamora.music.ui.AppViewModelFactory
import com.zazamora.music.ui.HomeViewModel
import com.zazamora.music.ui.MainViewModel
import com.zazamora.music.ui.SearchViewModel
import com.zazamora.music.ui.ZazamoraRoot
import com.zazamora.music.ui.theme.ZazamoraTheme
import com.zazamora.music.ui.theme.isDark

class MainActivity : ComponentActivity() {
    private val factory by lazy { AppViewModelFactory((application as ZazamoraApp).container) }
    private val vm: MainViewModel by viewModels { factory }
    private val homeVm: HomeViewModel by viewModels { factory }
    private val searchVm: SearchViewModel by viewModels { factory }

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* sin acción */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent {
            val prefs by vm.prefs.collectAsStateWithLifecycle()
            val dark = prefs.theme.isDark()
            DisposableEffect(dark) {
                val transparent = android.graphics.Color.TRANSPARENT
                val style = if (dark) SystemBarStyle.dark(transparent) else SystemBarStyle.light(transparent, transparent)
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
                onDispose { }
            }
            ZazamoraTheme(prefs.theme) {
                ZazamoraRoot(vm, homeVm, searchVm, factory)
            }
        }
    }
}
