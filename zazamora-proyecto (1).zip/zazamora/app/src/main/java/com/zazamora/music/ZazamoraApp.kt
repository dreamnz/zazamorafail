package com.zazamora.music

import android.app.Application
import com.zazamora.music.config.AppContainer

class ZazamoraApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
