package com.zazamora.music.config

import android.app.Application
import androidx.room.Room
import com.zazamora.music.BuildConfig
import com.zazamora.music.data.DownloadManager
import com.zazamora.music.data.local.AppDatabase
import com.zazamora.music.data.prefs.AudioQuality
import com.zazamora.music.data.prefs.UserPrefs
import com.zazamora.music.data.repository.MusicRepository
import com.zazamora.music.integration.JamendoProvider
import com.zazamora.music.integration.MusicProvider
import com.zazamora.music.player.PlaybackManager

/** Inyección manual de dependencias (sin librerías externas). */
class AppContainer(val app: Application) {
    val prefs = UserPrefs(app)
    val db: AppDatabase = Room.databaseBuilder(app, AppDatabase::class.java, "zazamora.db").build()

    val provider: MusicProvider = JamendoProvider(
        clientId = { prefs.state.value.clientId.ifBlank { BuildConfig.JAMENDO_CLIENT_ID } },
        highQuality = { prefs.state.value.quality == AudioQuality.HIGH }
    )

    val repo = MusicRepository(provider, db)
    val downloads = DownloadManager(app, repo)
    val player = PlaybackManager(app, repo)
}
