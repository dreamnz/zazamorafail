package com.zazamora.music.data

import android.content.Context
import com.zazamora.music.data.repository.MusicRepository
import com.zazamora.music.model.DownloadEntity
import com.zazamora.music.model.Track
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Descargas para uso sin conexión. Solo se descargan pistas que el proveedor marca como
 * descargables (audiodownload_allowed). Las descargas viven mientras el proceso esté activo.
 */
class DownloadManager(private val context: Context, private val repo: MusicRepository) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _progress = MutableStateFlow<Map<String, Int>>(emptyMap())
    val progress: StateFlow<Map<String, Int>> = _progress.asStateFlow()

    fun start(track: Track, notify: (String) -> Unit) {
        val url = track.downloadUrl
        if (!track.downloadAllowed || url.isNullOrBlank()) {
            notify("El autor no permite descargar esta pista")
            return
        }
        if (_progress.value.containsKey(track.id)) return
        scope.launch {
            _progress.update { it + (track.id to 0) }
            val dir = File(context.filesDir, "downloads").apply { mkdirs() }
            val tmp = File(dir, "${track.id}.part")
            val out = File(dir, "${track.id}.mp3")
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 15_000
                conn.readTimeout = 30_000
                conn.instanceFollowRedirects = true
                conn.setRequestProperty("User-Agent", "Zazamora/0.2 (Android)")
                try {
                    conn.connect()
                    if (conn.responseCode !in 200..299) throw IOException("HTTP ${conn.responseCode}")
                    val total = conn.contentLengthLong
                    var done = 0L
                    var lastPct = -1
                    conn.inputStream.use { input ->
                        tmp.outputStream().use { output ->
                            val buf = ByteArray(16 * 1024)
                            while (true) {
                                val n = input.read(buf)
                                if (n < 0) break
                                output.write(buf, 0, n)
                                done += n
                                if (total > 0) {
                                    val pct = (done * 100 / total).toInt()
                                    if (pct != lastPct) {
                                        lastPct = pct
                                        _progress.update { it + (track.id to pct) }
                                    }
                                }
                            }
                        }
                    }
                } finally {
                    conn.disconnect()
                }
                if (out.exists()) out.delete()
                if (!tmp.renameTo(out)) throw IOException("No se pudo guardar el archivo")
                repo.addDownload(DownloadEntity(track.id, out.absolutePath, out.length(), System.currentTimeMillis()))
                notify("Descargada: ${track.title}")
            } catch (e: Exception) {
                tmp.delete()
                notify("No se pudo descargar: ${e.message ?: "error de red"}")
            } finally {
                _progress.update { it - track.id }
            }
        }
    }

    fun delete(trackId: String) {
        scope.launch {
            repo.download(trackId)?.let { File(it.filePath).delete() }
            repo.removeDownload(trackId)
        }
    }
}
