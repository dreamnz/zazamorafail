package com.zazamora.music.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Copia local y reducida de imágenes elegidas por el usuario (avatar, portadas de playlist). */
object ImageStore {
    suspend fun saveScaled(context: Context, uri: Uri, dir: String, name: String, maxPx: Int = 800): String? =
        withContext(Dispatchers.IO) {
            try {
                val resolver = context.contentResolver
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / sample > maxPx * 2 || bounds.outHeight / sample > maxPx * 2) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                    ?: return@withContext null
                val scale = maxPx.toFloat() / maxOf(bmp.width, bmp.height)
                val out = if (scale < 1f) {
                    Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
                } else bmp
                val folder = File(context.filesDir, dir).apply { mkdirs() }
                val file = File(folder, name)
                file.outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                file.absolutePath
            } catch (e: Exception) {
                null
            }
        }

    fun delete(path: String?) {
        if (path != null) runCatching { File(path).delete() }
    }
}
