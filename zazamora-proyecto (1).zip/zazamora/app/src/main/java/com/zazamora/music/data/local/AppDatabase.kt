package com.zazamora.music.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import com.zazamora.music.model.Album
import com.zazamora.music.model.Artist
import com.zazamora.music.model.DownloadEntity
import com.zazamora.music.model.FavoriteEntity
import com.zazamora.music.model.HistoryEntity
import com.zazamora.music.model.PlaylistEntity
import com.zazamora.music.model.PlaylistItemEntity
import com.zazamora.music.model.PlaylistSummary
import com.zazamora.music.model.SearchHistoryEntity
import com.zazamora.music.model.Track
import kotlinx.coroutines.flow.Flow

@Dao
interface LibraryDao {
    // ---- pistas (caché) ----
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTracks(tracks: List<Track>)

    @Query("SELECT * FROM tracks WHERE id = :id")
    suspend fun trackById(id: String): Track?

    // ---- favoritos ----
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFavorite(f: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE trackId = :id")
    suspend fun removeFavorite(id: String)

    @Query("SELECT t.* FROM tracks t INNER JOIN favorites f ON t.id = f.trackId ORDER BY f.addedAt DESC")
    fun favorites(): Flow<List<Track>>

    @Query("SELECT trackId FROM favorites")
    fun favoriteIds(): Flow<List<String>>

    // ---- historial ----
    @Insert
    suspend fun addHistory(h: HistoryEntity)

    @Query("DELETE FROM history")
    suspend fun clearHistory()

    @Query("SELECT t.* FROM tracks t INNER JOIN history h ON t.id = h.trackId ORDER BY h.id DESC LIMIT :limit")
    fun history(limit: Int): Flow<List<Track>>

    @Query(
        "SELECT t.* FROM tracks t INNER JOIN " +
            "(SELECT trackId, MAX(id) AS mid FROM history GROUP BY trackId) h ON t.id = h.trackId " +
            "ORDER BY h.mid DESC LIMIT :limit"
    )
    fun recentDistinct(limit: Int): Flow<List<Track>>

    @Query("SELECT COUNT(*) FROM history")
    fun playCount(): Flow<Int>

    @Query("SELECT COALESCE(SUM(t.durationSec), 0) FROM history h INNER JOIN tracks t ON t.id = h.trackId")
    fun listenedSeconds(): Flow<Long>

    @Query(
        "SELECT t.artistName FROM history h INNER JOIN tracks t ON t.id = h.trackId " +
            "GROUP BY t.artistName ORDER BY COUNT(*) DESC LIMIT 1"
    )
    fun topArtist(): Flow<String?>

    // ---- álbumes guardados ----
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveAlbum(a: Album)

    @Query("DELETE FROM saved_albums WHERE id = :id")
    suspend fun unsaveAlbum(id: String)

    @Query("SELECT * FROM saved_albums ORDER BY savedAt DESC")
    fun savedAlbums(): Flow<List<Album>>

    // ---- artistas seguidos ----
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun followArtist(a: Artist)

    @Query("DELETE FROM followed_artists WHERE id = :id")
    suspend fun unfollowArtist(id: String)

    @Query("SELECT * FROM followed_artists ORDER BY followedAt DESC")
    fun followedArtists(): Flow<List<Artist>>

    // ---- playlists ----
    @Insert
    suspend fun insertPlaylist(p: PlaylistEntity): Long

    @Query("UPDATE playlists SET name = :name WHERE id = :id")
    suspend fun renamePlaylist(id: Long, name: String)

    @Query("UPDATE playlists SET coverPath = :path WHERE id = :id")
    suspend fun setPlaylistCover(id: Long, path: String?)

    @Query("SELECT coverPath FROM playlists WHERE id = :id")
    suspend fun playlistCover(id: Long): String?

    @Query("DELETE FROM playlists WHERE id = :id")
    suspend fun deletePlaylist(id: Long)

    @Query("DELETE FROM playlist_items WHERE playlistId = :id")
    suspend fun deletePlaylistItems(id: Long)

    @Query("SELECT * FROM playlists WHERE id = :id")
    fun playlist(id: Long): Flow<PlaylistEntity?>

    @Query(
        "SELECT p.id AS id, p.name AS name, p.coverPath AS coverPath, p.createdAt AS createdAt, " +
            "(SELECT COUNT(*) FROM playlist_items i WHERE i.playlistId = p.id) AS trackCount " +
            "FROM playlists p ORDER BY p.createdAt DESC"
    )
    fun playlists(): Flow<List<PlaylistSummary>>

    @Query(
        "SELECT t.* FROM tracks t INNER JOIN playlist_items i ON t.id = i.trackId " +
            "WHERE i.playlistId = :pid ORDER BY i.position"
    )
    fun playlistTracks(pid: Long): Flow<List<Track>>

    @Query("SELECT trackId FROM playlist_items WHERE playlistId = :pid ORDER BY position")
    suspend fun playlistItemIds(pid: Long): List<String>

    @Query("SELECT COUNT(*) FROM playlist_items WHERE playlistId = :pid AND trackId = :tid")
    suspend fun playlistContains(pid: Long, tid: String): Int

    @Query("SELECT MAX(position) FROM playlist_items WHERE playlistId = :pid")
    suspend fun maxPosition(pid: Long): Int?

    @Insert
    suspend fun insertPlaylistItem(item: PlaylistItemEntity)

    @Query("DELETE FROM playlist_items WHERE playlistId = :pid AND trackId = :tid")
    suspend fun removePlaylistItem(pid: Long, tid: String)

    @Query("UPDATE playlist_items SET position = :pos WHERE playlistId = :pid AND trackId = :tid")
    suspend fun setItemPosition(pid: Long, tid: String, pos: Int)

    // ---- descargas ----
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addDownload(d: DownloadEntity)

    @Query("SELECT * FROM downloads WHERE trackId = :id")
    suspend fun download(id: String): DownloadEntity?

    @Query("DELETE FROM downloads WHERE trackId = :id")
    suspend fun removeDownload(id: String)

    @Query("SELECT * FROM downloads")
    fun downloads(): Flow<List<DownloadEntity>>

    @Query("SELECT t.* FROM tracks t INNER JOIN downloads d ON t.id = d.trackId ORDER BY d.createdAt DESC")
    fun downloadedTracks(): Flow<List<Track>>

    @Query("SELECT COALESCE(SUM(sizeBytes), 0) FROM downloads")
    fun downloadBytes(): Flow<Long>

    // ---- historial de búsquedas ----
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addSearch(s: SearchHistoryEntity)

    @Query("DELETE FROM search_history WHERE term = :term")
    suspend fun removeSearch(term: String)

    @Query("DELETE FROM search_history")
    suspend fun clearSearches()

    @Query("SELECT term FROM search_history ORDER BY at DESC LIMIT 15")
    fun searches(): Flow<List<String>>
}

@Database(
    entities = [
        Track::class, Album::class, Artist::class, FavoriteEntity::class, HistoryEntity::class,
        PlaylistEntity::class, PlaylistItemEntity::class, DownloadEntity::class, SearchHistoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): LibraryDao
}
