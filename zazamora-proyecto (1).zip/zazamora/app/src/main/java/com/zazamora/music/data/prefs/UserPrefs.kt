package com.zazamora.music.data.prefs

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ThemeMode { DARK, LIGHT, SYSTEM }
enum class AudioQuality { NORMAL, HIGH }

data class Prefs(
    val name: String = "",
    val theme: ThemeMode = ThemeMode.DARK,
    val genres: Set<String> = emptySet(),
    val quality: AudioQuality = AudioQuality.HIGH,
    val avatarPath: String? = null,
    val clientId: String = ""
)

/** Preferencias ligeras (SharedPreferences) expuestas como StateFlow. */
class UserPrefs(context: Context) {
    private val sp: SharedPreferences = context.getSharedPreferences("zazamora_prefs", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(read())
    val state: StateFlow<Prefs> = _state.asStateFlow()

    private fun read() = Prefs(
        name = sp.getString("name", "") ?: "",
        theme = runCatching { ThemeMode.valueOf(sp.getString("theme", "DARK") ?: "DARK") }.getOrDefault(ThemeMode.DARK),
        genres = sp.getStringSet("genres", emptySet())?.toSet() ?: emptySet(),
        quality = runCatching { AudioQuality.valueOf(sp.getString("quality", "HIGH") ?: "HIGH") }
            .getOrDefault(AudioQuality.HIGH),
        avatarPath = sp.getString("avatar", null),
        clientId = sp.getString("client_id", "") ?: ""
    )

    private fun edit(block: SharedPreferences.Editor.() -> Unit) {
        sp.edit().apply(block).apply()
        _state.value = read()
    }

    fun setName(v: String) = edit { putString("name", v) }
    fun setTheme(v: ThemeMode) = edit { putString("theme", v.name) }
    fun setQuality(v: AudioQuality) = edit { putString("quality", v.name) }
    fun setAvatar(path: String?) = edit { putString("avatar", path) }
    fun setClientId(v: String) = edit { putString("client_id", v.trim()) }
    fun setGenres(v: Set<String>) = edit { putStringSet("genres", v) }
}
