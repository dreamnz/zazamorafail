package com.zazamora.music.data.repository

import androidx.room.withTransaction
import com.zazamora.music.data.local.AppDatabase
import com.zazamora.music.integration.MusicProvider
import com.zazamora.music.model.Album
import com.zazamora.music.model.Artist
import com.zazamora.music.model.DownloadEntity
import com.zazamora.music.model.FavoriteEntity
import com.zazamora.music.model.HistoryEntity
import com.zazamora.music.model.PlaylistEntity
import com.zazamora.music.model.PlaylistItemEntity
import com.zazamora.music.model.SearchHistoryEntity
import com.zazamora.music.model.SearchResults
import com.zazamora.music.model.Track
import com.zazamora.music.model.UiState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.map
import java.util.Collections

/** Ejecuta [block] y lo convierte en un [UiState] sin tragarse la cancelación. */
suspend fun <T> uiLoad(block: suspend () -> T): UiState<T> = try {
    UiState.Success(block())
} catch (e: CancellationException) {
    throw e
} catch (e: Exception) {
    UiState.Error(e.message ?: "Error desconocido")
}

suspend fun <T> attempt(block: suspend () -> T): Result<T> = try {
    Result.success(block())
} catch (e: CancellationException) {
    throw e
} catch (e: Exception) {
    Result.failure(e)
}

/** Punto único de acceso a datos: proveedor remoto + base de datos local. */
class MusicRepository(val provider: MusicProvider, private val db: AppDatabase) {
    private val dao = db.dao()
    private fun now() = System.currentTimeMillis()

    private suspend fun cache(list: List<Track>): List<Track> {
        if (list.isNotEmpty()) dao.upsertTracks(list)
        return list
    }

    // ---------- remoto ----------
    suspend fun popular() = cache(provider.popularTracks(24))
    suspend fun releases() = cache(provider.newReleases(24))
    suspend fun spanish() = cache(provider.spanishTracks(24))
    suspend fun byGenre(tag: String) = cache(provider.tracksByGenre(tag, 40))
    suspend fun popularAlbums() = provider.popularAlbums(16)
    suspend fun popularArtists() = provider.popularArtists(16)

    suspend fun search(q: String): SearchResults = coroutineScope {
        val t = async { provider.searchTracks(q) }
        val a = async { provider.searchAlbums(q) }
        val r = async { provider.searchArtists(q) }
        SearchResults(cache(t.await()), a.await(), r.await())
    }

    suspend fun albumDetail(id: String): Pair<Album?, List<Track>> = coroutineScope {
        val a = async { provider.album(id) }
        val t = async { cache(provider.albumTracks(id)) }
        a.await() to t.await()
    }

    data class ArtistDetail(val artist: Artist?, val tracks: List<Track>, val albums: List<Album>)

    suspend fun artistDetail(id: String): ArtistDetail = coroutineScope {
        val a = async { provider.artist(id) }
        val t = async { cache(provider.artistTracks(id)) }
        val al = async { provider.artistAlbums(id) }
        ArtistDetail(a.await(), t.await(), al.await())
    }

    // ---------- local: flujos ----------
    fun favorites() = dao.favorites()
    fun favoriteIds() = dao.favoriteIds()
    fun recent(limit: Int = 15) = dao.recentDistinct(limit)
    fun history(limit: Int = 200) = dao.history(limit)
    fun playCount() = dao.playCount()
    fun listenedSeconds() = dao.listenedSeconds()
    fun topArtist() = dao.topArtist()
    fun savedAlbums() = dao.savedAlbums()
    fun followedArtists() = dao.followedArtists()
    fun playlists() = dao.playlists()
    fun playlist(id: Long) = dao.playlist(id)
    fun playlistTracks(id: Long) = dao.playlistTracks(id)
    fun downloadedTracks() = dao.downloadedTracks()
    fun downloadBytes() = dao.downloadBytes()
    fun downloadPaths() = dao.downloads().map { list -> list.associate { it.trackId to it.filePath } }
    fun searchHistory() = dao.searches()

    // ---------- local: acciones ----------
    suspend fun trackById(id: String) = dao.trackById(id)

    suspend fun toggleFavorite(track: Track, isFavorite: Boolean) {
        if (isFavorite) {
            dao.removeFavorite(track.id)
        } else {
            dao.upsertTracks(listOf(track))
            dao.addFavorite(FavoriteEntity(track.id, now()))
        }
    }

    suspend fun toggleAlbum(album: Album, isSaved: Boolean) {
        if (isSaved) dao.unsaveAlbum(album.id) else dao.saveAlbum(album.copy(savedAt = now()))
    }

    suspend fun toggleArtist(artist: Artist, isFollowed: Boolean) {
        if (isFollowed) dao.unfollowArtist(artist.id) else dao.followArtist(artist.copy(followedAt = now()))
    }

    suspend fun recordPlay(trackId: String) = dao.addHistory(HistoryEntity(trackId = trackId, playedAt = now()))
    suspend fun clearHistory() = dao.clearHistory()

    suspend fun createPlaylist(name: String): Long =
        dao.insertPlaylist(PlaylistEntity(name = name.trim(), coverPath = null, createdAt = now()))

    suspend fun renamePlaylist(id: Long, name: String) = dao.renamePlaylist(id, name.trim())
    suspend fun playlistCover(id: Long) = dao.playlistCover(id)
    suspend fun setPlaylistCover(id: Long, path: String?) = dao.setPlaylistCover(id, path)

    suspend fun deletePlaylist(id: Long) = db.withTransaction {
        dao.deletePlaylistItems(id)
        dao.deletePlaylist(id)
    }

    /** @return false si la pista ya estaba en la playlist. */
    suspend fun addToPlaylist(pid: Long, track: Track): Boolean = db.withTransaction {
        if (dao.playlistContains(pid, track.id) > 0) return@withTransaction false
        dao.upsertTracks(listOf(track))
        val next = (dao.maxPosition(pid) ?: -1) + 1
        dao.insertPlaylistItem(PlaylistItemEntity(playlistId = pid, trackId = track.id, position = next))
        true
    }

    suspend fun removeFromPlaylist(pid: Long, trackId: String) = dao.removePlaylistItem(pid, trackId)

    suspend fun moveInPlaylist(pid: Long, trackId: String, delta: Int) = db.withTransaction {
        val ids = dao.playlistItemIds(pid).toMutableList()
        val i = ids.indexOf(trackId)
        val j = i + delta
        if (i < 0 || j < 0 || j >= ids.size) return@withTransaction
        Collections.swap(ids, i, j)
        ids.forEachIndexed { idx, tid -> dao.setItemPosition(pid, tid, idx) }
    }

    suspend fun addDownload(d: DownloadEntity) = dao.addDownload(d)
    suspend fun download(id: String) = dao.download(id)
    suspend fun removeDownload(id: String) = dao.removeDownload(id)

    suspend fun saveSearch(term: String) {
        val t = term.trim()
        if (t.length >= 2) dao.addSearch(SearchHistoryEntity(t, now()))
    }

    suspend fun removeSearch(term: String) = dao.removeSearch(term)
    suspend fun clearSearches() = dao.clearSearches()
}
