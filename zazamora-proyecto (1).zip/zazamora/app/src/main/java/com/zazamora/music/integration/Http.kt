package com.zazamora.music.integration

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

object Http {
    suspend fun getJson(url: String): JSONObject = withContext(Dispatchers.IO) {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15_000
            conn.readTimeout = 20_000
            conn.setRequestProperty("Accept", "application/json")
            conn.setRequestProperty("User-Agent", "Zazamora/0.2 (Android)")
            val code = conn.responseCode
            if (code !in 200..299) throw IOException("El servidor respondió con el código $code")
            val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            JSONObject(body)
        } catch (e: UnknownHostException) {
            throw IOException("Sin conexión a internet")
        } catch (e: SocketTimeoutException) {
            throw IOException("Tiempo de espera agotado")
        } catch (e: JSONException) {
            throw IOException("Respuesta no válida del servidor")
        } finally {
            conn.disconnect()
        }
    }
}
