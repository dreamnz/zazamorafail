package com.zazamora.music.integration

import com.zazamora.music.model.Album
import com.zazamora.music.model.Artist
import com.zazamora.music.model.Track
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/**
 * Jamendo (https://developer.jamendo.com): música independiente con licencias Creative Commons.
 * Streaming completo autorizado; descarga solo si la pista lo permite (audiodownload_allowed).
 */
class JamendoProvider(
    private val clientId: () -> String,
    private val highQuality: () -> Boolean
) : MusicProvider {

    override val id = "jamendo"
    override val name = "Jamendo"
    override val isConfigured: Boolean get() = clientId().isNotBlank()

    private fun String.enc(): String = URLEncoder.encode(this, "UTF-8")

    private fun JSONObject.str(key: String): String? =
        if (isNull(key)) null else optString(key).ifBlank { null }

    private fun JSONArray.objects(): List<JSONObject> =
        (0 until length()).mapNotNull { optJSONObject(it) }

    private suspend fun api(path: String, params: List<Pair<String, String>> = emptyList()): JSONArray {
        val cid = clientId().trim()
        if (cid.isEmpty()) throw ProviderException("Falta el client_id de Jamendo. Configúralo en Perfil.")
        val sb = StringBuilder("https://api.jamendo.com/v3.0/")
            .append(path).append("/?client_id=").append(cid.enc())
            .append("&format=json&imagesize=500")
        params.forEach { sb.append('&').append(it.first.enc()).append('=').append(it.second.enc()) }
        val json = Http.getJson(sb.toString())
        val headers = json.optJSONObject("headers")
        if (headers != null && headers.optInt("code", 0) != 0) {
            throw ProviderException(headers.optString("error_message").ifBlank { "Error del proveedor" })
        }
        return json.optJSONArray("results") ?: JSONArray()
    }

    private fun parseTrack(o: JSONObject): Track? {
        val audio = o.str("audio") ?: return null
        val id = o.str("id") ?: return null
        return Track(
            id = id,
            title = o.str("name") ?: "Sin título",
            artistId = o.str("artist_id") ?: "",
            artistName = o.str("artist_name") ?: "Artista desconocido",
            albumId = o.str("album_id") ?: "",
            albumName = o.str("album_name") ?: "",
            coverUrl = o.str("album_image") ?: o.str("image"),
            audioUrl = audio,
            durationSec = o.optInt("duration"),
            downloadUrl = o.str("audiodownload"),
            downloadAllowed = o.optBoolean("audiodownload_allowed", false)
        )
    }

    private fun parseAlbum(o: JSONObject): Album? {
        val id = o.str("id") ?: return null
        return Album(
            id = id,
            name = o.str("name") ?: "Sin título",
            artistId = o.str("artist_id") ?: "",
            artistName = o.str("artist_name") ?: "",
            coverUrl = o.str("image"),
            releaseDate = o.str("releasedate")
        )
    }

    private fun parseArtist(o: JSONObject): Artist? {
        val id = o.str("id") ?: return null
        return Artist(id = id, name = o.str("name") ?: "Artista", imageUrl = o.str("image"))
    }

    private suspend fun tracks(limit: Int, vararg p: Pair<String, String>): List<Track> {
        val fmt = if (highQuality()) "mp32" else "mp31"
        val arr = api("tracks", listOf("limit" to "$limit", "audioformat" to fmt) + p.toList())
        return arr.objects().mapNotNull(::parseTrack)
    }

    override suspend fun searchTracks(query: String, limit: Int) =
        tracks(limit, "search" to query, "order" to "relevance")

    override suspend fun searchAlbums(query: String, limit: Int): List<Album> =
        api("albums", listOf("namesearch" to query, "limit" to "$limit", "order" to "popularity_total"))
            .objects().mapNotNull(::parseAlbum)

    override suspend fun searchArtists(query: String, limit: Int): List<Artist> =
        api("artists", listOf("namesearch" to query, "limit" to "$limit"))
            .objects().mapNotNull(::parseArtist)

    override suspend fun popularTracks(limit: Int) = tracks(limit, "order" to "popularity_week")
    override suspend fun newReleases(limit: Int) = tracks(limit, "order" to "releasedate_desc")
    override suspend fun spanishTracks(limit: Int) =
        tracks(limit, "lang" to "es", "include" to "musicinfo", "order" to "popularity_month")

    override suspend fun tracksByGenre(tag: String, limit: Int) =
        tracks(limit, "tags" to tag, "order" to "popularity_week")

    override suspend fun popularAlbums(limit: Int): List<Album> =
        api("albums", listOf("limit" to "$limit", "order" to "popularity_week"))
            .objects().mapNotNull(::parseAlbum)

    override suspend fun popularArtists(limit: Int): List<Artist> =
        api("artists", listOf("limit" to "$limit", "order" to "popularity_week"))
            .objects().mapNotNull(::parseArtist)

    override suspend fun album(id: String): Album? =
        api("albums", listOf("id" to id)).objects().firstNotNullOfOrNull(::parseAlbum)

    override suspend fun albumTracks(id: String): List<Track> {
        val fmt = if (highQuality()) "mp32" else "mp31"
        val albumObj = api("albums/tracks", listOf("id" to id, "audioformat" to fmt)).objects().firstOrNull()
            ?: return emptyList()
        val tracksArr = albumObj.optJSONArray("tracks") ?: return emptyList()
        return tracksArr.objects().mapNotNull { t ->
            // Las pistas anidadas no repiten los datos del álbum: se completan aquí.
            if (t.isNull("album_id")) t.put("album_id", albumObj.optString("id"))
            if (t.isNull("album_name")) t.put("album_name", albumObj.optString("name"))
            if (t.isNull("artist_id")) t.put("artist_id", albumObj.optString("artist_id"))
            if (t.isNull("artist_name")) t.put("artist_name", albumObj.optString("artist_name"))
            if (t.isNull("album_image")) t.put("album_image", albumObj.optString("image"))
            parseTrack(t)
        }
    }

    override suspend fun artist(id: String): Artist? =
        api("artists", listOf("id" to id)).objects().firstNotNullOfOrNull(::parseArtist)

    override suspend fun artistTracks(id: String, limit: Int) =
        tracks(limit, "artist_id" to id, "order" to "popularity_total")

    override suspend fun artistAlbums(id: String): List<Album> =
        api("albums", listOf("artist_id" to id, "limit" to "30", "order" to "releasedate_desc"))
            .objects().mapNotNull(::parseAlbum)
}
