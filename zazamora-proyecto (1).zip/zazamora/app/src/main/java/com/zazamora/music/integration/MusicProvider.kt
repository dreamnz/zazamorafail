package com.zazamora.music.integration

import com.zazamora.music.model.Album
import com.zazamora.music.model.Artist
import com.zazamora.music.model.Track

class ProviderException(message: String) : Exception(message)

/**
 * Contrato de un proveedor musical. Toda pista devuelta DEBE tener una URL de audio reproducible
 * de forma legal; las pistas sin audio se descartan en la implementación.
 */
interface MusicProvider {
    val id: String
    val name: String
    val isConfigured: Boolean

    suspend fun searchTracks(query: String, limit: Int = 30): List<Track>
    suspend fun searchAlbums(query: String, limit: Int = 20): List<Album>
    suspend fun searchArtists(query: String, limit: Int = 20): List<Artist>

    suspend fun popularTracks(limit: Int): List<Track>
    suspend fun newReleases(limit: Int): List<Track>
    suspend fun spanishTracks(limit: Int): List<Track>
    suspend fun tracksByGenre(tag: String, limit: Int): List<Track>
    suspend fun popularAlbums(limit: Int): List<Album>
    suspend fun popularArtists(limit: Int): List<Artist>

    suspend fun album(id: String): Album?
    suspend fun albumTracks(id: String): List<Track>
    suspend fun artist(id: String): Artist?
    suspend fun artistTracks(id: String, limit: Int = 50): List<Track>
    suspend fun artistAlbums(id: String): List<Album>
}
