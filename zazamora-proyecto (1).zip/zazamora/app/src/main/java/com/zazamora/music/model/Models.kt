package com.zazamora.music.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Pista de un proveedor. También sirve de caché local para favoritos, playlists e historial. */
@Entity(tableName = "tracks")
data class Track(
    @PrimaryKey val id: String,
    val title: String,
    val artistId: String,
    val artistName: String,
    val albumId: String,
    val albumName: String,
    val coverUrl: String?,
    val audioUrl: String?,
    val durationSec: Int,
    val downloadUrl: String?,
    val downloadAllowed: Boolean
)

/** Álbum; como entidad representa los álbumes guardados por el usuario. */
@Entity(tableName = "saved_albums")
data class Album(
    @PrimaryKey val id: String,
    val name: String,
    val artistId: String,
    val artistName: String,
    val coverUrl: String?,
    val releaseDate: String?,
    val savedAt: Long = 0L
)

/** Artista; como entidad representa los artistas seguidos. */
@Entity(tableName = "followed_artists")
data class Artist(
    @PrimaryKey val id: String,
    val name: String,
    val imageUrl: String?,
    val followedAt: Long = 0L
)

@Entity(tableName = "favorites")
data class FavoriteEntity(@PrimaryKey val trackId: String, val addedAt: Long)

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val trackId: String,
    val playedAt: Long
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val coverPath: String?,
    val createdAt: Long
)

@Entity(tableName = "playlist_items")
data class PlaylistItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long,
    val trackId: String,
    val position: Int
)

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val trackId: String,
    val filePath: String,
    val sizeBytes: Long,
    val createdAt: Long
)

@Entity(tableName = "search_history")
data class SearchHistoryEntity(@PrimaryKey val term: String, val at: Long)

data class PlaylistSummary(
    val id: Long,
    val name: String,
    val coverPath: String?,
    val createdAt: Long,
    val trackCount: Int
)

data class SearchResults(
    val tracks: List<Track>,
    val albums: List<Album>,
    val artists: List<Artist>
)

data class Genre(val tag: String, val label: String)

object Genres {
    val all = listOf(
        Genre("pop", "Pop"), Genre("rock", "Rock"), Genre("electronic", "Electrónica"),
        Genre("hiphop", "Hip hop"), Genre("jazz", "Jazz"), Genre("classical", "Clásica"),
        Genre("ambient", "Ambient"), Genre("folk", "Folk"), Genre("metal", "Metal"),
        Genre("reggae", "Reggae"), Genre("latin", "Latina"), Genre("indie", "Indie"),
        Genre("lounge", "Lounge"), Genre("blues", "Blues"), Genre("punk", "Punk"),
        Genre("soundtrack", "Bandas sonoras")
    )

    fun byTag(tag: String): Genre? = all.firstOrNull { it.tag == tag }
}

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Error(val message: String) : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
}
