package com.zazamora.music.player

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.zazamora.music.data.repository.MusicRepository
import com.zazamora.music.model.Track
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import kotlin.random.Random

data class QueueItem(val mediaId: String, val title: String, val artist: String, val artworkUri: String?)

data class PlayerState(
    val hasMedia: Boolean = false,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val mediaId: String? = null,
    val title: String = "",
    val artist: String = "",
    val album: String = "",
    val artworkUri: String? = null,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val queue: List<QueueItem> = emptyList(),
    val currentIndex: Int = 0,
    val error: String? = null,
    val sleepEndsAt: Long? = null
)

/** Puente entre la UI y el servicio: controla el reproductor real a través de un MediaController. */
class PlaybackManager(private val context: Context, private val repo: MusicRepository) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var controller: MediaController? = null
    private var pending: (() -> Unit)? = null
    private var localPaths: Map<String, String> = emptyMap()
    private var lastRecorded: String? = null
    private var sleepJob: Job? = null

    private val _state = MutableStateFlow(PlayerState())
    val state: StateFlow<PlayerState> = _state.asStateFlow()

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            refreshAll()
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) record(controller?.currentMediaItem?.mediaId)
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            lastRecorded = null
            if (mediaItem != null && controller?.playWhenReady == true) record(mediaItem.mediaId)
        }

        override fun onPlayerError(error: PlaybackException) {
            val network = error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ||
                error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT
            val msg = if (network) "Sin conexión: no se puede reproducir esta pista"
            else "No se pudo reproducir esta pista"
            _state.update { it.copy(error = msg) }
            val c = controller ?: return
            // Errores no relacionados con la red: pasar a la siguiente pista de la cola.
            if (!network && c.hasNextMediaItem()) {
                c.seekToNextMediaItem()
                c.prepare()
                c.play()
            }
        }
    }

    init {
        scope.launch { repo.downloadPaths().collect { localPaths = it } }
        connect()
        scope.launch {
            while (true) {
                delay(500)
                val c = controller ?: continue
                if (c.isPlaying) {
                    _state.update {
                        it.copy(positionMs = c.currentPosition.coerceAtLeast(0), durationMs = c.duration.coerceAtLeast(0))
                    }
                }
            }
        }
    }

    private fun connect() {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(listener)
                refreshAll()
                pending?.invoke()
                pending = null
            } catch (e: Exception) {
                _state.update { it.copy(error = "No se pudo conectar con el servicio de reproducción") }
            }
        }, ContextCompat.getMainExecutor(context))
    }

    private fun record(id: String?) {
        if (id == null || id == lastRecorded) return
        lastRecorded = id
        scope.launch { repo.recordPlay(id) }
    }

    private fun refreshAll() {
        val c = controller ?: return
        val item = c.currentMediaItem
        val md = item?.mediaMetadata
        val queue = List(c.mediaItemCount) { i ->
            val m = c.getMediaItemAt(i)
            QueueItem(
                m.mediaId,
                m.mediaMetadata.title?.toString().orEmpty(),
                m.mediaMetadata.artist?.toString().orEmpty(),
                m.mediaMetadata.artworkUri?.toString()
            )
        }
        _state.update {
            it.copy(
                hasMedia = item != null,
                isPlaying = c.isPlaying,
                isBuffering = c.playbackState == Player.STATE_BUFFERING,
                mediaId = item?.mediaId,
                title = md?.title?.toString().orEmpty(),
                artist = md?.artist?.toString().orEmpty(),
                album = md?.albumTitle?.toString().orEmpty(),
                artworkUri = md?.artworkUri?.toString(),
                positionMs = c.currentPosition.coerceAtLeast(0),
                durationMs = c.duration.coerceAtLeast(0),
                shuffle = c.shuffleModeEnabled,
                repeatMode = c.repeatMode,
                queue = queue,
                currentIndex = c.currentMediaItemIndex,
                error = if (c.isPlaying) null else it.error
            )
        }
    }

    private fun toItem(t: Track): MediaItem {
        val uri = localPaths[t.id]?.let { Uri.fromFile(File(it)).toString() } ?: t.audioUrl.orEmpty()
        return MediaItem.Builder()
            .setMediaId(t.id)
            .setUri(uri)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(t.title)
                    .setArtist(t.artistName)
                    .setAlbumTitle(t.albumName)
                    .setArtworkUri(t.coverUrl?.let { Uri.parse(it) })
                    .build()
            )
            .build()
    }

    private fun withController(block: (MediaController) -> Unit) {
        val c = controller
        if (c != null) block(c) else pending = { controller?.let(block) }
    }

    // ---------- API pública ----------
    fun play(tracks: List<Track>, startIndex: Int = 0) {
        if (tracks.isEmpty()) return
        withController { c ->
            c.setMediaItems(tracks.map(::toItem), startIndex.coerceIn(0, tracks.lastIndex), 0L)
            c.prepare()
            c.play()
        }
    }

    fun playShuffled(tracks: List<Track>) {
        if (tracks.isEmpty()) return
        withController { c ->
            c.shuffleModeEnabled = true
            c.setMediaItems(tracks.map(::toItem), Random.nextInt(tracks.size), 0L)
            c.prepare()
            c.play()
        }
    }

    fun togglePlay() = withController { c ->
        if (c.isPlaying) {
            c.pause()
        } else {
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            c.play()
        }
    }

    fun next() = withController { it.seekToNext() }
    fun previous() = withController { it.seekToPrevious() }
    fun seekTo(ms: Long) = withController {
        it.seekTo(ms)
        _state.update { s -> s.copy(positionMs = ms) }
    }

    fun toggleShuffle() = withController { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    fun cycleRepeat() = withController {
        it.repeatMode = when (it.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun skipTo(index: Int) = withController { c ->
        c.seekToDefaultPosition(index)
        c.play()
    }

    fun playNext(track: Track) = withController { c ->
        if (c.mediaItemCount == 0) play(listOf(track)) else c.addMediaItem(c.currentMediaItemIndex + 1, toItem(track))
    }

    fun enqueue(track: Track) = withController { c ->
        if (c.mediaItemCount == 0) play(listOf(track)) else c.addMediaItem(toItem(track))
    }

    fun removeFromQueue(index: Int) = withController { it.removeMediaItem(index) }

    fun retry() = withController { c ->
        _state.update { it.copy(error = null) }
        c.prepare()
        c.play()
    }

    fun startSleepTimer(minutes: Int) {
        sleepJob?.cancel()
        val end = System.currentTimeMillis() + minutes * 60_000L
        _state.update { it.copy(sleepEndsAt = end) }
        sleepJob = scope.launch {
            delay(minutes * 60_000L)
            controller?.pause()
            _state.update { it.copy(sleepEndsAt = null) }
        }
    }

    fun cancelSleepTimer() {
        sleepJob?.cancel()
        _state.update { it.copy(sleepEndsAt = null) }
    }
}
