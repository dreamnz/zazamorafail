package com.zazamora.music.ui

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.zazamora.music.config.AppContainer
import com.zazamora.music.data.ImageStore
import com.zazamora.music.data.prefs.AudioQuality
import com.zazamora.music.data.prefs.ThemeMode
import com.zazamora.music.data.repository.attempt
import com.zazamora.music.data.repository.uiLoad
import com.zazamora.music.model.Album
import com.zazamora.music.model.Artist
import com.zazamora.music.model.Genre
import com.zazamora.music.model.Genres
import com.zazamora.music.model.SearchResults
import com.zazamora.music.model.Track
import com.zazamora.music.model.UiState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModelFactory(private val c: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when {
        modelClass.isAssignableFrom(MainViewModel::class.java) -> MainViewModel(c)
        modelClass.isAssignableFrom(HomeViewModel::class.java) -> HomeViewModel(c)
        modelClass.isAssignableFrom(SearchViewModel::class.java) -> SearchViewModel(c)
        modelClass.isAssignableFrom(DetailViewModel::class.java) -> DetailViewModel(c)
        else -> throw IllegalArgumentException("ViewModel desconocido: ${modelClass.name}")
    } as T
}

/** Estado de biblioteca, preferencias y acciones compartidas por todas las pantallas. */
class MainViewModel(private val c: AppContainer) : ViewModel() {
    private val repo = c.repo
    val pm = c.player

    val prefs = c.prefs.state
    val player = c.player.state
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val downloadProgress = c.downloads.progress

    private fun <T> Flow<T>.eager(initial: T): StateFlow<T> =
        stateIn(viewModelScope, SharingStarted.Eagerly, initial)

    val favoriteIds = repo.favoriteIds().map { it.toSet() }.eager(emptySet())
    val favorites = repo.favorites().eager(emptyList())
    val savedAlbums = repo.savedAlbums().eager(emptyList())
    val savedAlbumIds = savedAlbums.map { l -> l.map { it.id }.toSet() }.eager(emptySet())
    val followedArtists = repo.followedArtists().eager(emptyList())
    val followedIds = followedArtists.map { l -> l.map { it.id }.toSet() }.eager(emptySet())
    val playlists = repo.playlists().eager(emptyList())
    val recent = repo.recent().eager(emptyList())
    val history = repo.history().eager(emptyList())
    val downloadedTracks = repo.downloadedTracks().eager(emptyList())
    val downloadedIds = downloadedTracks.map { l -> l.map { it.id }.toSet() }.eager(emptySet())
    val downloadBytes = repo.downloadBytes().eager(0L)
    val playCount = repo.playCount().eager(0)
    val listenedSeconds = repo.listenedSeconds().eager(0L)
    val topArtist = repo.topArtist().eager(null)
    val nowPlayingId = c.player.state.map { it.mediaId }.distinctUntilChanged().eager(null)

    fun isConfigured() = c.provider.isConfigured
    fun providerName() = c.provider.name

    private fun say(msg: String) {
        messages.tryEmit(msg)
    }

    // ---- reproducción ----
    fun play(tracks: List<Track>, index: Int = 0) = c.player.play(tracks, index)
    fun playShuffled(tracks: List<Track>) = c.player.playShuffled(tracks)
    fun playNext(t: Track) {
        c.player.playNext(t); say("Se reproducirá a continuación")
    }

    fun enqueue(t: Track) {
        c.player.enqueue(t); say("Añadida a la cola")
    }

    // ---- favoritos / biblioteca ----
    fun toggleFavorite(t: Track) = viewModelScope.launch {
        val fav = t.id in favoriteIds.value
        repo.toggleFavorite(t, fav)
        say(if (fav) "Quitada de favoritos" else "Añadida a favoritos")
    }

    fun toggleFavoriteById(id: String) = viewModelScope.launch {
        repo.trackById(id)?.let { toggleFavorite(it) }
    }

    suspend fun trackById(id: String) = repo.trackById(id)

    fun toggleAlbum(a: Album) = viewModelScope.launch {
        val saved = a.id in savedAlbumIds.value
        repo.toggleAlbum(a, saved)
        say(if (saved) "Álbum quitado de la biblioteca" else "Álbum guardado")
    }

    fun toggleArtist(a: Artist) = viewModelScope.launch {
        val f = a.id in followedIds.value
        repo.toggleArtist(a, f)
        say(if (f) "Dejaste de seguir a ${a.name}" else "Sigues a ${a.name}")
    }

    fun clearHistory() = viewModelScope.launch { repo.clearHistory(); say("Historial borrado") }

    // ---- playlists ----
    fun playlist(id: Long) = repo.playlist(id)
    fun playlistTracks(id: Long) = repo.playlistTracks(id)

    fun createPlaylist(name: String, andAdd: Track? = null) = viewModelScope.launch {
        if (name.isBlank()) return@launch
        val id = repo.createPlaylist(name)
        if (andAdd != null) repo.addToPlaylist(id, andAdd)
        say("Playlist «${name.trim()}» creada")
    }

    fun renamePlaylist(id: Long, name: String) = viewModelScope.launch {
        if (name.isNotBlank()) repo.renamePlaylist(id, name)
    }

    fun deletePlaylist(id: Long) = viewModelScope.launch {
        ImageStore.delete(repo.playlistCover(id))
        repo.deletePlaylist(id)
        say("Playlist eliminada")
    }

    fun addToPlaylist(pid: Long, t: Track) = viewModelScope.launch {
        say(if (repo.addToPlaylist(pid, t)) "Añadida a la playlist" else "Ya estaba en la playlist")
    }

    fun removeFromPlaylist(pid: Long, trackId: String) = viewModelScope.launch { repo.removeFromPlaylist(pid, trackId) }
    fun moveInPlaylist(pid: Long, trackId: String, delta: Int) = viewModelScope.launch { repo.moveInPlaylist(pid, trackId, delta) }

    fun setPlaylistCover(pid: Long, uri: Uri) = viewModelScope.launch {
        val old = repo.playlistCover(pid)
        val path = ImageStore.saveScaled(c.app, uri, "covers", "pl_${pid}_${System.currentTimeMillis()}.jpg")
        if (path != null) {
            repo.setPlaylistCover(pid, path)
            ImageStore.delete(old)
        } else say("No se pudo usar esa imagen")
    }

    // ---- descargas ----
    fun download(t: Track) = c.downloads.start(t) { say(it) }
    fun deleteDownload(id: String) {
        c.downloads.delete(id); say("Descarga eliminada")
    }

    // ---- perfil ----
    fun setName(v: String) = c.prefs.setName(v)
    fun setTheme(v: ThemeMode) = c.prefs.setTheme(v)
    fun setQuality(v: AudioQuality) = c.prefs.setQuality(v)
    fun setClientId(v: String) {
        c.prefs.setClientId(v); say("Client ID guardado")
    }

    fun toggleGenre(tag: String) {
        val cur = prefs.value.genres
        c.prefs.setGenres(if (tag in cur) cur - tag else cur + tag)
    }

    fun setAvatar(uri: Uri) = viewModelScope.launch {
        val old = prefs.value.avatarPath
        val path = ImageStore.saveScaled(c.app, uri, "avatar", "avatar_${System.currentTimeMillis()}.jpg", 512)
        if (path != null) {
            c.prefs.setAvatar(path)
            ImageStore.delete(old)
        } else say("No se pudo usar esa imagen")
    }
}

data class HomeData(
    val popular: List<Track>,
    val releases: List<Track>,
    val spanish: List<Track>,
    val albums: List<Album>,
    val artists: List<Artist>,
    val forYou: List<Pair<Genre, List<Track>>>
)

class HomeViewModel(private val c: AppContainer) : ViewModel() {
    private val _state = MutableStateFlow<UiState<HomeData>>(UiState.Loading)
    val state: StateFlow<UiState<HomeData>> = _state.asStateFlow()
    private var job: Job? = null

    init {
        viewModelScope.launch {
            c.prefs.state.map { it.genres to it.clientId }.distinctUntilChanged().collect { reload() }
        }
    }

    fun reload() {
        job?.cancel()
        job = viewModelScope.launch {
            _state.value = UiState.Loading
            _state.value = uiLoad { loadAll() }
        }
    }

    private suspend fun loadAll(): HomeData = coroutineScope {
        val repo = c.repo
        val genres = c.prefs.state.value.genres.mapNotNull { Genres.byTag(it) }.take(2)
        val popular = async { attempt { repo.popular() } }
        val releases = async { attempt { repo.releases() } }
        val spanish = async { attempt { repo.spanish() } }
        val albums = async { attempt { repo.popularAlbums() } }
        val artists = async { attempt { repo.popularArtists() } }
        val forYou = genres.map { g -> async { g to attempt { repo.byGenre(g.tag) } } }

        val p = popular.await(); val r = releases.await(); val s = spanish.await()
        val al = albums.await(); val ar = artists.await()
        val all = listOf(p, r, s, al, ar)
        if (all.all { it.isFailure }) throw (p.exceptionOrNull() ?: Exception("Error desconocido"))
        HomeData(
            popular = p.getOrNull().orEmpty(),
            releases = r.getOrNull().orEmpty(),
            spanish = s.getOrNull().orEmpty(),
            albums = al.getOrNull().orEmpty(),
            artists = ar.getOrNull().orEmpty(),
            forYou = forYou.map { it.await() }.mapNotNull { (g, res) ->
                res.getOrNull()?.takeIf { it.isNotEmpty() }?.let { g to it }
            }
        )
    }
}

class SearchViewModel(private val c: AppContainer) : ViewModel() {
    val query = MutableStateFlow("")
    private val retry = MutableStateFlow(0)
    val history = c.repo.searchHistory().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    @OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
    val results: StateFlow<UiState<SearchResults>?> =
        combine(query.map { it.trim() }.debounce(350).distinctUntilChanged(), retry) { q, _ -> q }
            .flatMapLatest { q ->
                if (q.length < 2) flowOf<UiState<SearchResults>?>(null)
                else flow<UiState<SearchResults>?> {
                    emit(UiState.Loading)
                    emit(uiLoad { c.repo.search(q) })
                }
            }
            .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    fun onQuery(q: String) {
        query.value = q
    }

    fun retry() {
        retry.value++
    }

    fun submit() {
        val q = query.value
        viewModelScope.launch { c.repo.saveSearch(q) }
    }

    fun pick(term: String) {
        query.value = term
        viewModelScope.launch { c.repo.saveSearch(term) }
    }

    fun removeHistory(term: String) {
        viewModelScope.launch { c.repo.removeSearch(term) }
    }

    fun clearHistory() {
        viewModelScope.launch { c.repo.clearSearches() }
    }
}

data class DetailData(
    val kind: String,
    val title: String,
    val subtitle: String,
    val coverUrl: String?,
    val tracks: List<Track>,
    val albums: List<Album> = emptyList(),
    val album: Album? = null,
    val artist: Artist? = null
)

class DetailViewModel(private val c: AppContainer) : ViewModel() {
    private val _state = MutableStateFlow<UiState<DetailData>>(UiState.Loading)
    val state: StateFlow<UiState<DetailData>> = _state.asStateFlow()
    private var key = ""

    fun load(kind: String, id: String, force: Boolean = false) {
        if (!force && key == "$kind/$id") return
        key = "$kind/$id"
        viewModelScope.launch {
            _state.value = UiState.Loading
            _state.value = uiLoad {
                when (kind) {
                    "album" -> {
                        val (album, tracks) = c.repo.albumDetail(id)
                        DetailData(
                            kind, album?.name ?: tracks.firstOrNull()?.albumName ?: "Álbum",
                            album?.artistName ?: tracks.firstOrNull()?.artistName.orEmpty(),
                            album?.coverUrl ?: tracks.firstOrNull()?.coverUrl, tracks, album = album
                        )
                    }
                    "artist" -> {
                        val d = c.repo.artistDetail(id)
                        DetailData(
                            kind, d.artist?.name ?: d.tracks.firstOrNull()?.artistName ?: "Artista",
                            "Artista", d.artist?.imageUrl, d.tracks, d.albums, artist = d.artist
                        )
                    }
                    else -> {
                        val g = Genres.byTag(id)
                        val tracks = c.repo.byGenre(id)
                        DetailData(kind, g?.label ?: id, "Género", tracks.firstOrNull()?.coverUrl, tracks)
                    }
                }
            }
        }
    }

    fun reload() {
        val parts = key.split("/", limit = 2)
        if (parts.size == 2) load(parts[0], parts[1], force = true)
    }
}
