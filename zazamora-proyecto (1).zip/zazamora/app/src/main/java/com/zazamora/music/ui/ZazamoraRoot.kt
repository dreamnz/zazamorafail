package com.zazamora.music.ui

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Column
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.zazamora.music.model.Track
import com.zazamora.music.ui.components.Actions
import com.zazamora.music.ui.components.AddToPlaylistDialog
import com.zazamora.music.ui.components.LocalActions
import com.zazamora.music.ui.components.MiniPlayer
import com.zazamora.music.ui.screens.DetailScreen
import com.zazamora.music.ui.screens.HomeScreen
import com.zazamora.music.ui.screens.LibraryScreen
import com.zazamora.music.ui.screens.PlayerScreen
import com.zazamora.music.ui.screens.PlaylistScreen
import com.zazamora.music.ui.screens.ProfileScreen
import com.zazamora.music.ui.screens.SearchScreen

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("home", "Inicio", Icons.Rounded.Home),
    Tab("search", "Buscar", Icons.Rounded.Search),
    Tab("library", "Biblioteca", Icons.Rounded.LibraryMusic),
    Tab("profile", "Perfil", Icons.Rounded.Person)
)

@Composable
fun ZazamoraRoot(
    vm: MainViewModel,
    homeVm: HomeViewModel,
    searchVm: SearchViewModel,
    factory: ViewModelProvider.Factory
) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val player by vm.player.collectAsStateWithLifecycle()
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    var playlistTrack by remember { mutableStateOf<Track?>(null) }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it) } }

    val actions = remember(vm, nav) {
        Actions(
            vm = vm,
            openAlbum = { nav.navigate("detail/album/$it") },
            openArtist = { nav.navigate("detail/artist/$it") },
            addToPlaylist = { playlistTrack = it }
        )
    }

    fun goTab(r: String) = nav.navigate(r) {
        popUpTo("home") { saveState = true }
        launchSingleTop = true
        restoreState = true
    }

    CompositionLocalProvider(LocalActions provides actions) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = {
                if (route != "player") {
                    Column {
                        if (player.hasMedia) {
                            MiniPlayer(
                                state = player,
                                onToggle = vm.pm::togglePlay,
                                onNext = vm.pm::next,
                                onOpen = { nav.navigate("player") { launchSingleTop = true } }
                            )
                        }
                        NavigationBar {
                            tabs.forEach { t ->
                                NavigationBarItem(
                                    selected = route == t.route,
                                    onClick = { goTab(t.route) },
                                    icon = { Icon(t.icon, t.label) },
                                    label = { Text(t.label) }
                                )
                            }
                        }
                    }
                }
            }
        ) { pad ->
            NavHost(nav, startDestination = "home") {
                composable("home") {
                    HomeScreen(
                        vm, homeVm, pad,
                        onOpenGenre = { nav.navigate("detail/genre/$it") },
                        onOpenProfile = { goTab("profile") }
                    )
                }
                composable("search") {
                    SearchScreen(
                        vm, searchVm, pad,
                        onOpenGenre = { nav.navigate("detail/genre/$it") },
                        onOpenPlaylist = { nav.navigate("playlist/$it") }
                    )
                }
                composable("library") { LibraryScreen(vm, pad, onOpenPlaylist = { nav.navigate("playlist/$it") }) }
                composable("profile") { ProfileScreen(vm, pad) }
                composable(
                    "detail/{kind}/{id}",
                    arguments = listOf(
                        navArgument("kind") { type = NavType.StringType },
                        navArgument("id") { type = NavType.StringType }
                    )
                ) { e ->
                    val dv: DetailViewModel = viewModel(factory = factory)
                    DetailScreen(
                        kind = e.arguments?.getString("kind").orEmpty(),
                        id = e.arguments?.getString("id").orEmpty(),
                        vm = vm, dv = dv, pad = pad, onBack = { nav.popBackStack() }
                    )
                }
                composable(
                    "playlist/{id}",
                    arguments = listOf(navArgument("id") { type = NavType.LongType })
                ) { e ->
                    PlaylistScreen(e.arguments?.getLong("id") ?: 0L, vm, pad, onBack = { nav.popBackStack() })
                }
                composable(
                    "player",
                    enterTransition = { slideInVertically(tween(320)) { it } },
                    exitTransition = { fadeOut(tween(200)) },
                    popEnterTransition = { fadeIn(tween(200)) },
                    popExitTransition = { slideOutVertically(tween(320)) { it } }
                ) { PlayerScreen(vm, pad, onClose = { nav.popBackStack() }) }
            }
        }

        playlistTrack?.let { t ->
            AddToPlaylistDialog(
                track = t,
                playlists = playlists,
                onPick = { vm.addToPlaylist(it, t); playlistTrack = null },
                onCreate = { vm.createPlaylist(it, t); playlistTrack = null },
                onDismiss = { playlistTrack = null }
            )
        }
    }
}
