package com.zazamora.music.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zazamora.music.model.UiState
import com.zazamora.music.ui.DetailViewModel
import com.zazamora.music.ui.MainViewModel
import com.zazamora.music.ui.components.*

@Composable
fun DetailScreen(kind: String, id: String, vm: MainViewModel, dv: DetailViewModel, pad: PaddingValues, onBack: () -> Unit) {
    LaunchedEffect(kind, id) { dv.load(kind, id) }
    val state by dv.state.collectAsStateWithLifecycle()
    val savedAlbums by vm.savedAlbumIds.collectAsStateWithLifecycle()
    val followed by vm.followedIds.collectAsStateWithLifecycle()
    val actions = LocalActions.current

    LazyColumn(contentPadding = pad.listPadding(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        item {
            IconButton(onClick = onBack, modifier = Modifier.padding(start = 8.dp, top = 4.dp)) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Volver")
            }
        }
        when (val s = state) {
            UiState.Loading -> item { LoadingBox() }
            is UiState.Error -> item { ErrorBox(s.message, onRetry = dv::reload) }
            is UiState.Success -> {
                val d = s.data
                item {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Cover(d.coverUrl, d.title, Modifier.size(220.dp), 24.dp, circle = d.kind == "artist")
                        Spacer(Modifier.height(16.dp))
                        Text(d.title, style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
                        Text(d.subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Button(onClick = { vm.play(d.tracks, 0) }, enabled = d.tracks.isNotEmpty()) {
                                Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Reproducir")
                            }
                            FilledTonalButton(onClick = { vm.playShuffled(d.tracks) }, enabled = d.tracks.isNotEmpty()) {
                                Icon(Icons.Rounded.Shuffle, null); Spacer(Modifier.width(6.dp)); Text("Aleatorio")
                            }
                        }
                        d.album?.let { a ->
                            val saved = a.id in savedAlbums
                            OutlinedButton(onClick = { vm.toggleAlbum(a) }, modifier = Modifier.padding(top = 8.dp)) {
                                Text(if (saved) "Quitar de la biblioteca" else "Guardar álbum")
                            }
                        }
                        d.artist?.let { a ->
                            val f = a.id in followed
                            OutlinedButton(onClick = { vm.toggleArtist(a) }, modifier = Modifier.padding(top = 8.dp)) {
                                Text(if (f) "Siguiendo" else "Seguir artista")
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                    }
                }
                if (d.tracks.isEmpty()) item { EmptyBox("No hay pistas reproducibles disponibles.") }
                itemsIndexed(d.tracks, key = { _, t -> "dt${t.id}" }) { i, t -> TrackRow(t, onClick = { vm.play(d.tracks, i) }) }
                if (d.albums.isNotEmpty()) {
                    item {
                        Spacer(Modifier.height(20.dp))
                        SectionTitle("Discografía")
                        Spacer(Modifier.height(12.dp))
                        Carousel(d.albums) { _, a -> AlbumCard(a, onClick = { actions.openAlbum(a.id) }) }
                    }
                }
            }
        }
    }
}
