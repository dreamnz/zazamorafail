package com.zazamora.music.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zazamora.music.model.Genres
import com.zazamora.music.model.Track
import com.zazamora.music.model.UiState
import com.zazamora.music.ui.HomeViewModel
import com.zazamora.music.ui.MainViewModel
import com.zazamora.music.ui.components.*
import java.io.File
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    vm: MainViewModel,
    home: HomeViewModel,
    pad: PaddingValues,
    onOpenGenre: (String) -> Unit,
    onOpenProfile: () -> Unit
) {
    val state by home.state.collectAsStateWithLifecycle()
    val prefs by vm.prefs.collectAsStateWithLifecycle()
    val recent by vm.recent.collectAsStateWithLifecycle()
    val actions = LocalActions.current
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val greeting = when {
        hour < 12 -> "Buenos días"
        hour < 20 -> "Buenas tardes"
        else -> "Buenas noches"
    }
    val name = prefs.name.ifBlank { "melómano" }

    @Composable
    fun trackSection(title: String, tracks: List<Track>) {
        if (tracks.isEmpty()) return
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SectionTitle(title)
            Carousel(tracks) { i, t -> TrackCard(t, onClick = { vm.play(tracks, i) }) }
        }
    }

    LazyColumn(contentPadding = pad.listPadding(), verticalArrangement = Arrangement.spacedBy(26.dp)) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(greeting, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(name, style = MaterialTheme.typography.headlineLarge)
                }
                Cover(
                    prefs.avatarPath?.let { File(it) }, name,
                    Modifier.size(48.dp).clickable(onClick = onOpenProfile), circle = true
                )
            }
        }

        if (!vm.isConfigured()) {
            item {
                Card(
                    Modifier.fillMaxWidth().padding(horizontal = 20.dp).clickable(onClick = onOpenProfile),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Conecta el catálogo", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Zazamora necesita un client_id gratuito de Jamendo para buscar y reproducir música. " +
                                "Toca aquí para configurarlo en Perfil.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }

        if (recent.isNotEmpty()) {
            item { trackSection("Escuchado recientemente", recent) }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SectionTitle(if (prefs.genres.isEmpty()) "Géneros" else "Tus géneros")
                val ordered = Genres.all.sortedByDescending { it.tag in prefs.genres }
                LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(ordered) { g ->
                        AssistChip(
                            onClick = { onOpenGenre(g.tag) },
                            label = { Text(g.label) },
                            colors = AssistChipDefaults.assistChipColors(
                                containerColor = if (g.tag in prefs.genres) MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.surfaceContainerHigh
                            )
                        )
                    }
                }
            }
        }

        when (val s = state) {
            UiState.Loading -> item { LoadingBox() }
            is UiState.Error -> item { ErrorBox(s.message, onRetry = home::reload) }
            is UiState.Success -> {
                val d = s.data
                d.forYou.forEach { (g, tracks) -> item { trackSection("Para ti · ${g.label}", tracks) } }
                item { trackSection("Popular esta semana", d.popular) }
                item { trackSection("Lanzamientos recientes", d.releases) }
                if (d.albums.isNotEmpty()) item {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SectionTitle("Álbumes destacados")
                        Carousel(d.albums) { _, a -> AlbumCard(a, onClick = { actions.openAlbum(a.id) }) }
                    }
                }
                if (d.artists.isNotEmpty()) item {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SectionTitle("Artistas recomendados")
                        Carousel(d.artists) { _, a -> ArtistCard(a, onClick = { actions.openArtist(a.id) }) }
                    }
                }
                item { trackSection("Descubre en español", d.spanish) }
                if (d.popular.isEmpty() && d.releases.isEmpty() && d.albums.isEmpty()) {
                    item { EmptyBox("No se encontró contenido. Revisa tu conexión y el client_id.") }
                }
            }
        }
    }
}
