package com.zazamora.music.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zazamora.music.ui.MainViewModel
import com.zazamora.music.ui.components.*
import androidx.compose.runtime.saveable.rememberSaveable

private val tabs = listOf("Favoritas", "Playlists", "Álbumes", "Artistas", "Descargas", "Historial")

@Composable
fun LibraryScreen(vm: MainViewModel, pad: PaddingValues, onOpenPlaylist: (Long) -> Unit) {
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val albums by vm.savedAlbums.collectAsStateWithLifecycle()
    val artists by vm.followedArtists.collectAsStateWithLifecycle()
    val downloads by vm.downloadedTracks.collectAsStateWithLifecycle()
    val bytes by vm.downloadBytes.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val actions = LocalActions.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var newPlaylist by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(top = pad.calculateTopPadding())) {
        Text("Tu biblioteca", style = MaterialTheme.typography.headlineLarge, modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp))
        ScrollableTabRow(
            selectedTabIndex = tab, edgePadding = 12.dp, containerColor = androidx.compose.ui.graphics.Color.Transparent,
            divider = {}
        ) {
            tabs.forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
            }
        }

        LazyColumn(contentPadding = PaddingValues(top = 8.dp, bottom = pad.calculateBottomPadding() + 24.dp)) {
            when (tab) {
                0 -> {
                    if (favorites.isEmpty()) item { EmptyBox("Aún no tienes favoritas.\nToca ⋮ en una canción para añadirla.") }
                    itemsIndexed(favorites, key = { _, t -> "f${t.id}" }) { i, t -> TrackRow(t, onClick = { vm.play(favorites, i) }) }
                }
                1 -> {
                    item {
                        TextButton(onClick = { newPlaylist = true }, modifier = Modifier.padding(horizontal = 12.dp)) {
                            Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(8.dp)); Text("Nueva playlist")
                        }
                    }
                    if (playlists.isEmpty()) item { EmptyBox("Crea tu primera playlist. Funciona sin conexión.") }
                    items(playlists, key = { "p${it.id}" }) { p -> PlaylistRow(p) { onOpenPlaylist(p.id) } }
                }
                2 -> {
                    if (albums.isEmpty()) item { EmptyBox("Guarda álbumes desde su pantalla de detalle.") }
                    items(albums, key = { "a${it.id}" }) { a ->
                        Row(
                            Modifier.fillMaxWidth().clickable { actions.openAlbum(a.id) }.padding(horizontal = 20.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Cover(a.coverUrl, a.name, Modifier.size(56.dp), 12.dp)
                            Spacer(Modifier.width(14.dp))
                            Column {
                                Text(a.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                                Text(a.artistName, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
                3 -> {
                    if (artists.isEmpty()) item { EmptyBox("Sigue artistas desde su perfil.") }
                    items(artists, key = { "ar${it.id}" }) { a ->
                        Row(
                            Modifier.fillMaxWidth().clickable { actions.openArtist(a.id) }.padding(horizontal = 20.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Cover(a.imageUrl, a.name, Modifier.size(56.dp), circle = true)
                            Spacer(Modifier.width(14.dp))
                            Text(a.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
                4 -> {
                    item {
                        Text(
                            "Espacio ocupado: ${formatBytes(bytes)} · ${downloads.size} pistas",
                            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                        )
                    }
                    if (downloads.isEmpty()) item { EmptyBox("Descarga pistas (si el autor lo permite) desde el menú ⋮ para escucharlas sin conexión.") }
                    itemsIndexed(downloads, key = { _, t -> "d${t.id}" }) { i, t ->
                        TrackRow(t, onClick = { vm.play(downloads, i) }, trailing = {
                            IconButton(onClick = { vm.deleteDownload(t.id) }) { Icon(Icons.Rounded.Delete, "Eliminar descarga") }
                        })
                    }
                }
                else -> {
                    item {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Últimas reproducciones", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                            if (history.isNotEmpty()) TextButton(onClick = vm::clearHistory) { Text("Borrar") }
                        }
                    }
                    if (history.isEmpty()) item { EmptyBox("Todavía no has reproducido nada.") }
                    itemsIndexed(history) { i, t -> TrackRow(t, onClick = { vm.play(history, i) }) }
                }
            }
        }
    }

    if (newPlaylist) {
        NamePromptDialog("Nueva playlist", "", "Crear", { vm.createPlaylist(it); newPlaylist = false }, { newPlaylist = false })
    }
}
