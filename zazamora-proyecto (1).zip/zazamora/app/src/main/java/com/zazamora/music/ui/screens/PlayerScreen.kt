@file:OptIn(ExperimentalMaterial3Api::class)

package com.zazamora.music.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.DownloadDone
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import com.zazamora.music.model.Track
import com.zazamora.music.ui.MainViewModel
import com.zazamora.music.ui.components.*
import kotlinx.coroutines.delay

@Composable
fun PlayerScreen(vm: MainViewModel, pad: PaddingValues, onClose: () -> Unit) {
    val st by vm.player.collectAsStateWithLifecycle()
    val favIds by vm.favoriteIds.collectAsStateWithLifecycle()
    val dlIds by vm.downloadedIds.collectAsStateWithLifecycle()
    val progress by vm.downloadProgress.collectAsStateWithLifecycle()
    val actions = LocalActions.current
    val pm = vm.pm
    val mid = st.mediaId
    val track by produceState<Track?>(null, st.mediaId) { value = st.mediaId?.let { vm.trackById(it) } }

    var showQueue by remember { mutableStateOf(false) }
    var showSleep by remember { mutableStateOf(false) }
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }

    val scale by animateFloatAsState(if (st.isPlaying) 1f else 0.86f, tween(450), label = "cover")
    val duration = st.durationMs.coerceAtLeast(1L).toFloat()
    val position = if (dragging) dragValue else st.positionMs.toFloat().coerceIn(0f, duration)
    val isFav = mid != null && mid in favIds

    // Refresca la cuenta atrás del temporizador mientras esté activo.
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(st.sleepEndsAt) {
        while (st.sleepEndsAt != null) { now = System.currentTimeMillis(); delay(15_000) }
    }

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(MaterialTheme.colorScheme.surfaceContainerHighest, MaterialTheme.colorScheme.background))
        )
    ) {
        Column(
            Modifier.fillMaxSize().padding(top = pad.calculateTopPadding(), bottom = pad.calculateBottomPadding())
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.Rounded.KeyboardArrowDown, "Cerrar", Modifier.size(32.dp)) }
                Text(
                    "Reproduciendo", Modifier.weight(1f), textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                IconButton(onClick = { showQueue = true }) { Icon(Icons.Rounded.QueueMusic, "Cola de reproducción") }
            }

            Spacer(Modifier.weight(0.5f))
            Cover(
                st.artworkUri, st.album.ifBlank { st.title },
                Modifier.fillMaxWidth().aspectRatio(1f).graphicsLayer { scaleX = scale; scaleY = scale },
                28.dp
            )
            Spacer(Modifier.weight(0.5f))

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(st.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.headlineMedium)
                    Text(
                        st.artist, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.clickable(enabled = track?.artistId?.isNotBlank() == true) {
                            track?.let { onClose(); actions.openArtist(it.artistId) }
                        }
                    )
                    if (st.album.isNotBlank()) Text(
                        st.album, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.clickable(enabled = track?.albumId?.isNotBlank() == true) {
                            track?.let { onClose(); actions.openAlbum(it.albumId) }
                        }
                    )
                }
                IconButton(onClick = { st.mediaId?.let(vm::toggleFavoriteById) }) {
                    Icon(
                        if (isFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        if (isFav) "Quitar de favoritos" else "Añadir a favoritos",
                        tint = if (isFav) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            if (st.error != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(st.error.orEmpty(), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f, fill = false))
                    TextButton(onClick = pm::retry) { Text("Reintentar") }
                }
            }

            Slider(
                value = position,
                onValueChange = { dragging = true; dragValue = it },
                onValueChangeFinished = { pm.seekTo(dragValue.toLong()); dragging = false },
                valueRange = 0f..duration,
                modifier = Modifier.fillMaxWidth()
            )
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatMs(position.toLong()), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(formatMs(st.durationMs), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = pm::toggleShuffle) {
                    Icon(
                        Icons.Rounded.Shuffle, if (st.shuffle) "Aleatorio activado" else "Aleatorio desactivado",
                        tint = if (st.shuffle) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = pm::previous, modifier = Modifier.size(56.dp)) { Icon(Icons.Rounded.SkipPrevious, "Anterior", Modifier.size(36.dp)) }
                Box(
                    Modifier.size(72.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary).clickable(onClick = pm::togglePlay),
                    contentAlignment = Alignment.Center
                ) {
                    if (st.isBuffering && !st.isPlaying) {
                        CircularProgressIndicator(Modifier.size(34.dp), color = MaterialTheme.colorScheme.onPrimary, strokeWidth = 3.dp)
                    } else {
                        Icon(
                            if (st.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            if (st.isPlaying) "Pausar" else "Reproducir",
                            tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(42.dp)
                        )
                    }
                }
                IconButton(onClick = pm::next, modifier = Modifier.size(56.dp)) { Icon(Icons.Rounded.SkipNext, "Siguiente", Modifier.size(36.dp)) }
                IconButton(onClick = pm::cycleRepeat) {
                    val on = st.repeatMode != Player.REPEAT_MODE_OFF
                    Icon(
                        if (st.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                        when (st.repeatMode) {
                            Player.REPEAT_MODE_ONE -> "Repetir canción"
                            Player.REPEAT_MODE_ALL -> "Repetir cola"
                            else -> "Repetición desactivada"
                        },
                        tint = if (on) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { showSleep = true }) {
                    Icon(Icons.Rounded.Bedtime, null, Modifier.size(20.dp))
                    Spacer(Modifier.width(6.dp))
                    val end = st.sleepEndsAt
                    Text(if (end != null) "${((end - now) / 60_000L + 1).coerceAtLeast(1)} min" else "Temporizador")
                }
                TextButton(onClick = { track?.let(actions.addToPlaylist) }, enabled = track != null) {
                    Icon(Icons.Rounded.Add, null, Modifier.size(20.dp))
                    Spacer(Modifier.width(6.dp)); Text("Playlist")
                }
                val t = track
                val downloaded = mid != null && mid in dlIds
                val inProgress = mid != null && progress.containsKey(mid)
                TextButton(
                    onClick = { if (t != null) { if (downloaded) vm.deleteDownload(t.id) else vm.download(t) } },
                    enabled = t != null && !inProgress && (downloaded || t.downloadAllowed)
                ) {
                    Icon(if (downloaded) Icons.Rounded.DownloadDone else Icons.Rounded.Download, null, Modifier.size(20.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (inProgress) "${progress[mid]}%" else if (downloaded) "Descargada" else "Descargar")
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }

    if (showQueue) {
        ModalBottomSheet(onDismissRequest = { showQueue = false }, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
            Text("Cola de reproducción", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
            LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
                itemsIndexed(st.queue, key = { i, q -> "$i-${q.mediaId}" }) { i, q ->
                    val current = i == st.currentIndex
                    Row(
                        Modifier.fillMaxWidth().clickable { pm.skipTo(i) }.padding(start = 20.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Cover(q.artworkUri, q.title, Modifier.size(44.dp), 10.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                q.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall,
                                color = if (current) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface
                            )
                            Text(q.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (!current) IconButton(onClick = { pm.removeFromQueue(i) }) { Icon(Icons.Rounded.Close, "Quitar de la cola") }
                    }
                }
            }
        }
    }

    if (showSleep) {
        AlertDialog(
            onDismissRequest = { showSleep = false },
            title = { Text("Temporizador de apagado") },
            text = {
                Column {
                    listOf(15, 30, 45, 60).forEach { m ->
                        Text(
                            "$m minutos",
                            Modifier.fillMaxWidth().clickable { pm.startSleepTimer(m); now = System.currentTimeMillis(); showSleep = false }.padding(vertical = 12.dp)
                        )
                    }
                    if (st.sleepEndsAt != null) {
                        Text(
                            "Desactivar temporizador", color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.fillMaxWidth().clickable { pm.cancelSleepTimer(); showSleep = false }.padding(vertical = 12.dp)
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showSleep = false }) { Text("Cerrar") } }
        )
    }
}
