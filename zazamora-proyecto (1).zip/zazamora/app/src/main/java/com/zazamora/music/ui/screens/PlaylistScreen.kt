package com.zazamora.music.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zazamora.music.model.PlaylistEntity
import com.zazamora.music.model.Track
import com.zazamora.music.ui.MainViewModel
import com.zazamora.music.ui.components.*
import java.io.File

@Composable
fun PlaylistScreen(id: Long, vm: MainViewModel, pad: PaddingValues, onBack: () -> Unit) {
    val playlistFlow = remember(id) { vm.playlist(id) }
    val tracksFlow = remember(id) { vm.playlistTracks(id) }
    val playlist by playlistFlow.collectAsStateWithLifecycle(initialValue = null as PlaylistEntity?)
    val tracks by tracksFlow.collectAsStateWithLifecycle(initialValue = emptyList<Track>())
    var rename by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.setPlaylistCover(id, uri)
    }

    val pl = playlist
    if (pl == null) {
        // Eliminada o aún cargando
        Box(Modifier.fillMaxSize().padding(pad)) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Volver") }
        }
        return
    }

    LazyColumn(contentPadding = pad.listPadding()) {
        item {
            IconButton(onClick = onBack, modifier = Modifier.padding(start = 8.dp, top = 4.dp)) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Volver")
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Cover(
                    pl.coverPath?.let { File(it) }, pl.name,
                    Modifier.size(200.dp).clickable {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    24.dp
                )
                Text("Toca la portada para cambiarla", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                Text(pl.name, style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
                Text("${tracks.size} canciones", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = { vm.play(tracks, 0) }, enabled = tracks.isNotEmpty()) {
                        Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Reproducir")
                    }
                    FilledTonalButton(onClick = { vm.playShuffled(tracks) }, enabled = tracks.isNotEmpty()) {
                        Icon(Icons.Rounded.Shuffle, null); Spacer(Modifier.width(6.dp)); Text("Aleatorio")
                    }
                    IconButton(onClick = { rename = true }) { Icon(Icons.Rounded.Edit, "Renombrar") }
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Rounded.Delete, "Eliminar playlist") }
                }
                Spacer(Modifier.height(12.dp))
            }
        }
        if (tracks.isEmpty()) item { EmptyBox("Playlist vacía. Añade canciones desde el menú ⋮ de cualquier pista.") }
        itemsIndexed(tracks, key = { _, t -> "pt${t.id}" }) { i, t ->
            TrackRow(t, onClick = { vm.play(tracks, i) }, trailing = {
                IconButton(onClick = { vm.moveInPlaylist(id, t.id, -1) }, enabled = i > 0) { Icon(Icons.Rounded.ArrowUpward, "Subir") }
                IconButton(onClick = { vm.moveInPlaylist(id, t.id, 1) }, enabled = i < tracks.lastIndex) { Icon(Icons.Rounded.ArrowDownward, "Bajar") }
                IconButton(onClick = { vm.removeFromPlaylist(id, t.id) }) { Icon(Icons.Rounded.Close, "Quitar de la playlist") }
            })
        }
    }

    if (rename) {
        NamePromptDialog("Renombrar playlist", pl.name, "Guardar", { vm.renamePlaylist(id, it); rename = false }, { rename = false })
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("¿Eliminar «${pl.name}»?") },
            text = { Text("Las canciones no se borran de ningún sitio; solo desaparece la playlist.") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; vm.deletePlaylist(id); onBack() }) { Text("Eliminar") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancelar") } }
        )
    }
}
