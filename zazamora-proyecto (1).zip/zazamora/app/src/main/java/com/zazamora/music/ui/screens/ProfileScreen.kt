package com.zazamora.music.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zazamora.music.data.prefs.AudioQuality
import com.zazamora.music.data.prefs.ThemeMode
import com.zazamora.music.model.Genres
import com.zazamora.music.ui.MainViewModel
import com.zazamora.music.ui.components.*
import java.io.File

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileScreen(vm: MainViewModel, pad: PaddingValues) {
    val prefs by vm.prefs.collectAsStateWithLifecycle()
    val plays by vm.playCount.collectAsStateWithLifecycle()
    val secs by vm.listenedSeconds.collectAsStateWithLifecycle()
    val top by vm.topArtist.collectAsStateWithLifecycle()
    val followed by vm.followedArtists.collectAsStateWithLifecycle()
    val bytes by vm.downloadBytes.collectAsStateWithLifecycle()
    val actions = LocalActions.current
    var clientId by remember(prefs.clientId) { mutableStateOf(prefs.clientId) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.setAvatar(uri)
    }

    @Composable
    fun Block(title: String, content: @Composable ColumnScope.() -> Unit) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }

    LazyColumn(contentPadding = pad.listPadding(), verticalArrangement = Arrangement.spacedBy(24.dp)) {
        item {
            Column(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Cover(
                    prefs.avatarPath?.let { File(it) }, prefs.name.ifBlank { "zazamora" },
                    Modifier.size(112.dp).clickable { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    circle = true
                )
                TextButton(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                    Text("Cambiar foto")
                }
            }
        }
        item {
            Block("Nombre") {
                OutlinedTextField(
                    value = prefs.name, onValueChange = vm::setName, singleLine = true,
                    modifier = Modifier.fillMaxWidth(), placeholder = { Text("¿Cómo te llamamos?") }
                )
            }
        }
        item {
            Block("Tus estadísticas") {
                Text("Reproducciones: $plays", style = MaterialTheme.typography.bodyLarge)
                Text("Tiempo estimado: ${secs / 60} min", style = MaterialTheme.typography.bodyLarge)
                Text("Artista más escuchado: ${top ?: "—"}", style = MaterialTheme.typography.bodyLarge)
                Text("Descargas: ${formatBytes(bytes)}", style = MaterialTheme.typography.bodyLarge)
            }
        }
        item {
            Block("Géneros favoritos") {
                Text("Cambian las recomendaciones de Inicio.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Genres.all.forEach { g ->
                        FilterChip(selected = g.tag in prefs.genres, onClick = { vm.toggleGenre(g.tag) }, label = { Text(g.label) })
                    }
                }
            }
        }
        if (followed.isNotEmpty()) item {
            Block("Artistas favoritos") {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    followed.forEach { a -> AssistChip(onClick = { actions.openArtist(a.id) }, label = { Text(a.name) }) }
                }
            }
        }
        item {
            Block("Apariencia") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(ThemeMode.DARK to "Oscuro", ThemeMode.SYSTEM to "Sistema", ThemeMode.LIGHT to "Claro").forEach { (m, label) ->
                        FilterChip(selected = prefs.theme == m, onClick = { vm.setTheme(m) }, label = { Text(label) })
                    }
                }
            }
        }
        item {
            Block("Calidad de audio") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = prefs.quality == AudioQuality.NORMAL, onClick = { vm.setQuality(AudioQuality.NORMAL) }, label = { Text("Normal · ahorra datos") })
                    FilterChip(selected = prefs.quality == AudioQuality.HIGH, onClick = { vm.setQuality(AudioQuality.HIGH) }, label = { Text("Alta") })
                }
                Text(
                    "Se aplica a las pistas que cargues a partir de ahora.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        item {
            Block("Catálogo: ${vm.providerName()}") {
                Text(
                    "Música independiente con licencias Creative Commons: streaming completo legal. " +
                        "Crea una cuenta gratuita en devportal.jamendo.com, registra una app y pega aquí su client_id.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = clientId, onValueChange = { clientId = it }, singleLine = true,
                    modifier = Modifier.fillMaxWidth(), label = { Text("client_id de Jamendo") }
                )
                Button(onClick = { vm.setClientId(clientId) }, enabled = clientId.trim() != prefs.clientId) { Text("Guardar") }
            }
        }
        item {
            Block("Datos") {
                OutlinedButton(onClick = vm::clearHistory) { Text("Borrar historial de reproducción") }
                Text(
                    "Zazamora 0.2 · Reproductor real (Media3) · Sin anuncios",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
