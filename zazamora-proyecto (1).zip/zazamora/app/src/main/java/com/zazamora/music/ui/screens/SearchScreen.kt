package com.zazamora.music.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zazamora.music.model.Genres
import com.zazamora.music.model.UiState
import com.zazamora.music.ui.MainViewModel
import com.zazamora.music.ui.SearchViewModel
import com.zazamora.music.ui.components.*
import java.text.Normalizer

private fun norm(s: String) =
    Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    vm: MainViewModel,
    sv: SearchViewModel,
    pad: PaddingValues,
    onOpenGenre: (String) -> Unit,
    onOpenPlaylist: (Long) -> Unit
) {
    val query by sv.query.collectAsStateWithLifecycle()
    val results by sv.results.collectAsStateWithLifecycle()
    val history by sv.history.collectAsStateWithLifecycle()
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val actions = LocalActions.current
    val focus = LocalFocusManager.current
    val q = query.trim()

    Column(Modifier.fillMaxSize().padding(top = pad.calculateTopPadding())) {
        OutlinedTextField(
            value = query,
            onValueChange = sv::onQuery,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
            placeholder = { Text("Canciones, artistas, álbumes…") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            trailingIcon = {
                if (query.isNotEmpty()) IconButton(onClick = { sv.onQuery("") }) { Icon(Icons.Rounded.Close, "Borrar") }
            },
            singleLine = true,
            shape = MaterialTheme.shapes.extraLarge,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { sv.submit(); focus.clearFocus() })
        )

        LazyColumn(contentPadding = PaddingValues(bottom = pad.calculateBottomPadding() + 24.dp)) {
            if (q.length < 2) {
                if (history.isNotEmpty()) {
                    item {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Búsquedas recientes", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                            TextButton(onClick = sv::clearHistory) { Text("Borrar") }
                        }
                    }
                    items(history, key = { it }) { term ->
                        Row(
                            Modifier.fillMaxWidth().clickable { sv.pick(term) }.padding(start = 20.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(term, Modifier.weight(1f).padding(vertical = 12.dp))
                            IconButton(onClick = { sv.removeHistory(term) }) { Icon(Icons.Rounded.Close, "Quitar") }
                        }
                    }
                }
                item {
                    Spacer(Modifier.height(16.dp))
                    SectionTitle("Explorar géneros")
                    Spacer(Modifier.height(10.dp))
                    LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(Genres.all) { g ->
                            SuggestionChip(onClick = { onOpenGenre(g.tag) }, label = { Text(g.label) })
                        }
                    }
                }
            } else {
                // Sugerencias a partir del historial
                val suggestions = history.filter { norm(it).contains(norm(q)) && norm(it) != norm(q) }.take(3)
                if (suggestions.isNotEmpty()) item {
                    LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(suggestions) { s -> SuggestionChip(onClick = { sv.pick(s) }, label = { Text(s) }) }
                    }
                }
                val genreMatches = Genres.all.filter { norm(it.label).contains(norm(q)) || it.tag.contains(norm(q)) }
                val playlistMatches = playlists.filter { norm(it.name).contains(norm(q)) }

                if (genreMatches.isNotEmpty()) item {
                    Spacer(Modifier.height(8.dp))
                    SectionTitle("Géneros")
                    Spacer(Modifier.height(8.dp))
                    LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(genreMatches) { g -> AssistChip(onClick = { onOpenGenre(g.tag) }, label = { Text(g.label) }) }
                    }
                }
                if (playlistMatches.isNotEmpty()) {
                    item { Spacer(Modifier.height(12.dp)); SectionTitle("Tus playlists") }
                    items(playlistMatches, key = { "pl${it.id}" }) { p -> PlaylistRow(p) { onOpenPlaylist(p.id) } }
                }

                when (val r = results) {
                    null, UiState.Loading -> item { LoadingBox() }
                    is UiState.Error -> item { ErrorBox(r.message, onRetry = sv::retry) }
                    is UiState.Success -> {
                        val d = r.data
                        if (d.tracks.isEmpty() && d.albums.isEmpty() && d.artists.isEmpty()) {
                            item { EmptyBox("Sin resultados para «$q»") }
                        }
                        if (d.artists.isNotEmpty()) item {
                            Spacer(Modifier.height(12.dp))
                            SectionTitle("Artistas")
                            Spacer(Modifier.height(10.dp))
                            Carousel(d.artists) { _, a -> ArtistCard(a, onClick = { sv.submit(); actions.openArtist(a.id) }) }
                        }
                        if (d.albums.isNotEmpty()) item {
                            Spacer(Modifier.height(18.dp))
                            SectionTitle("Álbumes y discografías")
                            Spacer(Modifier.height(10.dp))
                            Carousel(d.albums) { _, a -> AlbumCard(a, onClick = { sv.submit(); actions.openAlbum(a.id) }) }
                        }
                        if (d.tracks.isNotEmpty()) {
                            item { Spacer(Modifier.height(18.dp)); SectionTitle("Canciones") }
                            itemsIndexed(d.tracks, key = { _, t -> "t${t.id}" }) { i, t ->
                                TrackRow(t, onClick = { sv.submit(); vm.play(d.tracks, i) })
                            }
                        }
                    }
                }
            }
        }
    }
}
