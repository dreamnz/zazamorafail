package com.zazamora.music.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zazamora.music.data.prefs.ThemeMode

val Navy = Color(0xFF071426)
val NavyBlue = Color(0xFF102746)
val Electric = Color(0xFF4169E1)
val SoftBlue = Color(0xFF789CFF)
val SoftWhite = Color(0xFFF5F7FC)
val BlueGray = Color(0xFF9AAAC0)

private val DarkScheme = darkColorScheme(
    primary = Electric, onPrimary = SoftWhite,
    primaryContainer = NavyBlue, onPrimaryContainer = SoftBlue,
    secondary = SoftBlue, onSecondary = Navy,
    secondaryContainer = Color(0xFF17335A), onSecondaryContainer = SoftWhite,
    background = Navy, onBackground = SoftWhite,
    surface = Navy, onSurface = SoftWhite,
    surfaceVariant = NavyBlue, onSurfaceVariant = BlueGray,
    surfaceContainerLowest = Navy, surfaceContainerLow = Color(0xFF0A1B33),
    surfaceContainer = Color(0xFF0D2140), surfaceContainerHigh = NavyBlue,
    surfaceContainerHighest = Color(0xFF17335A),
    outline = Color(0xFF2B4468), outlineVariant = Color(0xFF1B3354),
    error = Color(0xFFFF8A8A)
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF2F54C9), onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE5FF), onPrimaryContainer = Navy,
    secondary = Color(0xFF2F54C9), onSecondary = Color.White,
    secondaryContainer = Color(0xFFDCE5FF), onSecondaryContainer = Navy,
    background = SoftWhite, onBackground = Navy,
    surface = SoftWhite, onSurface = Navy,
    surfaceVariant = Color(0xFFE3EAF8), onSurfaceVariant = Color(0xFF4A5B75),
    surfaceContainerLowest = Color.White, surfaceContainerLow = Color(0xFFEEF2FB),
    surfaceContainer = Color(0xFFE9EEF9), surfaceContainerHigh = Color(0xFFE3EAF8),
    surfaceContainerHighest = Color(0xFFDCE5F5),
    outline = Color(0xFF8A9BB8), outlineVariant = Color(0xFFC9D4EA),
    error = Color(0xFFB3261E)
)

private val ZazamoraTypography = Typography(
    headlineLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 30.sp, lineHeight = 36.sp, letterSpacing = (-0.5).sp),
    headlineMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 24.sp, lineHeight = 30.sp, letterSpacing = (-0.3).sp),
    titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 26.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
    titleSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.Medium, fontSize = 14.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp),
)

private val ZazamoraShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun ThemeMode.isDark(): Boolean = when (this) {
    ThemeMode.DARK -> true
    ThemeMode.LIGHT -> false
    ThemeMode.SYSTEM -> isSystemInDarkTheme()
}

@Composable
fun ZazamoraTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (mode.isDark()) DarkScheme else LightScheme,
        typography = ZazamoraTypography,
        shapes = ZazamoraShapes,
        content = content
    )
}
