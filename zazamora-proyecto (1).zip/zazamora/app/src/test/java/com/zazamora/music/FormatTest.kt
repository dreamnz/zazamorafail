package com.zazamora.music

import com.zazamora.music.ui.components.formatBytes
import com.zazamora.music.ui.components.formatDuration
import org.junit.Assert.assertEquals
import org.junit.Test

class FormatTest {
    @Test fun duration() {
        assertEquals("0:05", formatDuration(5))
        assertEquals("3:07", formatDuration(187))
    }

    @Test fun bytes() {
        assertEquals("512 B", formatBytes(512))
        assertEquals("1.5 MB", formatBytes(1_572_864))
    }
}
